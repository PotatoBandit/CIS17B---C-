#ifndef POSITION_H
#define POSITION_H
#include "include.h"
#include <string>
using namespace std;

class Position
{
public:
    Position();
    Position(string name, string description);
    string toString();
private:
    string name;
    string description;
};

#endif // POSITION_H

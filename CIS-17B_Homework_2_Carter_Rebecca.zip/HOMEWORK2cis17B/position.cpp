#include "include.h"
#include "position.h"
#include <string>

using namespace std;


Position::Position()
{
    name = "Unemployed";
    description = "Watches TV";
}

Position::Position(string name, string description)
{
    this->name = name;
    this->description = description;
}

string Position::toString()
{
    return  name + "(" + description + ")";
}



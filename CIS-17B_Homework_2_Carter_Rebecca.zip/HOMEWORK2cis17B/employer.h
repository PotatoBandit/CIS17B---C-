#ifndef EMPLOYER_H
#define EMPLOYER_H
#include "include.h"
#include <string>
using namespace std;

class Employer
{
public:
    Employer();
    Employer(string name, string market);
    string toString();
    bool hire(Person& newHire, Position *pos);
private:
    string name;
    string market;
};

#endif // EMPLOYER_H

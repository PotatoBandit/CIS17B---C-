#include "person.h"
#include "employer.h"
#include "position.h"


Person::Person()
{
    this->m_name = "John";
    this->m_employer = new Employer();
    this->m_position = new Position();
    this->m_employed = false;
}

Person::Person(string name)
{
    this->m_name = name;
    this->m_employer = new Employer();
    this->m_position = new Position();
    this->m_employed = false;
}

void Person::setPosition(Employer *newC, Position *newP)
{
    this->m_employer = newC;
    this->m_position = newP;
    this->m_employed = true;
}

string Person::toString()
{
    return  "\t" + m_name + ":\n\t" + "Position: " + getPosition().toString();
}

Position Person::getPosition()
{
    if (!m_employed)
    {
        Position somethingFunny("Clicker", "Watch TV all day");
        return somethingFunny;
    }

    else
    {
        return *m_position;
    }
}

Employer Person::getEmployer()
{
    if(!m_employed)
    {
        Employer somethingFunny("Self", "Going to be homeless");
        return somethingFunny;
    }
    else
    {
        return *m_employer;
    }
}

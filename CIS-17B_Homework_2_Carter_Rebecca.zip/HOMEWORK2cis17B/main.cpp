
#include "person.h"
#include "employer.h"
#include "position.h"

#include <iostream>

using namespace std;
int main()
{
   Employer emp1("StarFleet Federation", "Going where no man has gone before.");
   Employer emp2("Borg", "Destruction of mankind.");

   Person employee1("Jean-Luc Picard");
   Person employee2("Wesley Crusher");
   Person employee3("George Lucas");

   Position p1("Captain", "Command the Starship Enterprise.");
   Position p2("Janitor" , "Cleanse the facilities");


   p1.toString();
   p2.toString();

   emp1.hire(employee1, &p1);
   emp2.hire(employee2, &p2);

   cout << "Company:" << endl;
   cout << emp1.toString() << endl;
   cout << "Employees:" << endl;
   cout << employee1.toString() << endl;

   cout << endl << endl << endl;

   cout << "Company:" << endl;
   cout << emp2.toString() << endl;
   cout << "Employees:" << endl;
   cout << employee2.toString() << endl;


   cout << endl << endl << endl;
   cout << "Seeking Employment" << endl;
   cout << employee3.toString() << endl;

    return 0;

}

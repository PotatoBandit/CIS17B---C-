#include "include.h"
#include "person.h"
#include "employer.h"
#include "position.h"

Employer::Employer()
{
    name = "";
    market = "";
}

Employer::Employer(string name, string market)
{
    this->name = name;
    this->market = market;
}

string Employer::toString()
{
    return name + ": " + market;

}

bool Employer::hire(Person& newHire, Position *pos)
{
    newHire.setPosition(this, pos);
    return true;
}

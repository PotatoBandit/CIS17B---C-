#ifndef PERSON_H
#define PERSON_H
#include "include.h"
#include <string>


using namespace std;

class Person
{
public:
    Person();
    Person(string name);
    string toString();
    void setPosition(Employer *newC, Position *newP);
    Position getPosition();
    Employer getEmployer();

private:
    string m_name;
    bool m_employed;
    Position *m_position;
    Employer *m_employer;
};

#endif // PERSON_H
